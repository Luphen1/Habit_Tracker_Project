def list_habits(habits):
    """Return a list of habit names."""
    return [h.name for h in habits]

def habits_by_periodicity(habits, periodicity):
    """Return habits filtered by periodicity."""
    return [h for h in habits if h.periodicity == periodicity]

def longest_streak(habits):
    """Return the longest streak among all habits."""
    return max((h.streak() for h in habits), default=0)

def longest_streak_per_habit(habits):
    """Return streaks for each habit individually."""
    return {h.name: h.streak() for h in habits}




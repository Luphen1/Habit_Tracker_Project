# cli.py
# Command-line interface for interacting with the habit tracker

import argparse
from habit import Habit
from database import (
    init_db, save_habit, get_all_habits,
    complete_habit
)
from analytics import list_habits, longest_streak, longest_streak_per_habit

def run_cli():
    """Run the command-line interface."""
    parser = argparse.ArgumentParser(description="Habit Tracker CLI")

    # Make 'action' optional with nargs='?' and set default to 'list'
    parser.add_argument(
        "action",
        choices=["list", "add", "complete", "streaks"],
        nargs="?",
        default="list",
        help="Action to perform (default: list)"
    )

    parser.add_argument("--name", help="Name of the habit")
    parser.add_argument("--periodicity", choices=["daily", "weekly"], help="Habit frequency")
    args = parser.parse_args()

    # Initialize database
    init_db()
    habits = get_all_habits()

    if args.action == "list":
        print("\n========== HABITS ==========")
        for h in habits:
            print(f"- {h.name} ({h.periodicity}) | Streak: {h.streak()}")
        print("============================\n")

    elif args.action == "add":
        if args.name and args.periodicity:
            save_habit(Habit(args.name, args.periodicity))
            print(f"Habit '{args.name}' added.")
        else:
            print("Provide --name and --periodicity.")

    elif args.action == "complete":
        if args.name:
            complete_habit(args.name)
        else:
            print("Provide --name.")

    elif args.action == "streaks":
        if args.name:
            for h in habits:
                if h.name == args.name:
                    print(f"Streak for '{args.name}': {h.streak()}")
                    break
            else:
                print(f"Habit '{args.name}' not found.")
        else:
            print("Longest streak:", longest_streak(habits))
            print("Streaks per habit:", longest_streak_per_habit(habits))

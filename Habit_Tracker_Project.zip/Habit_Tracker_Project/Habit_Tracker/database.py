import sqlite3
from datetime import datetime, timedelta
from typing import List
from habit import Habit

DB_FILE = "habits.db"  # SQLite database file name

def init_db() -> None:
    """Create required tables if they do not exist."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()

        # Create habits table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                periodicity TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        # Create completions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS completions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                habit_id INTEGER NOT NULL,
                completed_at TEXT NOT NULL,
                FOREIGN KEY(habit_id) REFERENCES habits(id)
            )
        """)

def save_habit(habit: Habit) -> None:
    """Insert a new habit into the database."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR IGNORE INTO habits (name, periodicity, created_at)
            VALUES (?, ?, ?)
        """, (habit.name, habit.periodicity, habit.created_at.isoformat()))

def get_completions(habit_id: int) -> List[datetime]:
    """Return all completion timestamps for a habit."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT completed_at FROM completions WHERE habit_id=?", (habit_id,))
        return [datetime.fromisoformat(row[0]) for row in cursor.fetchall()]

def get_all_habits() -> List[Habit]:
    """Return all habits with their completion history."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, periodicity, created_at FROM habits")
        rows = cursor.fetchall()

    habits = []
    for habit_id, name, periodicity, created_at in rows:
        habit = Habit(name, periodicity, datetime.fromisoformat(created_at))
        habit.completions = sorted(get_completions(habit_id))
        habits.append(habit)

    return habits

def complete_habit(habit_name: str, date: datetime = None) -> None:
    """Mark a habit as completed (optionally backdated)."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()

        cursor.execute("SELECT id FROM habits WHERE name=?", (habit_name,))
        row = cursor.fetchone()

        if not row:
            print(f"Habit '{habit_name}' not found.")
            return

        habit_id = row[0]
        timestamp = (date or datetime.now()).date().isoformat()

        # Prevent duplicate completion for same day
        cursor.execute("SELECT 1 FROM completions WHERE habit_id=? AND completed_at=?", (habit_id, timestamp))
        if cursor.fetchone():
            print(f"Habit '{habit_name}' already completed on {timestamp}.")
            return

        cursor.execute("INSERT INTO completions (habit_id, completed_at) VALUES (?, ?)", (habit_id, timestamp))

def populate_default_habits() -> None:
    """Insert 5 predefined habits and 4 weeks of example data."""
    if get_all_habits():  # Only populate if DB is empty
        return

    defaults = [
        Habit("Brush teeth", "daily"),
        Habit("Workout", "daily"),
        Habit("Read a book", "daily"),
        Habit("Clean house", "weekly"),
        Habit("Call family", "weekly")
    ]

    for h in defaults:
        save_habit(h)

    today = datetime.now()

    # Add 28 days of daily completions
    for i in range(28):
        day = today - timedelta(days=28 - i)
        complete_habit("Brush teeth", day)
        complete_habit("Workout", day)
        complete_habit("Read a book", day)

    # Add 4 weeks of weekly completions
    for i in range(4):
        week = today - timedelta(weeks=4 - i)
        complete_habit("Clean house", week)
        complete_habit("Call family", week)

from datetime import datetime
from typing import List, Optional

class Habit:
    """
    Represents a habit with a name, periodicity, creation date,
    and a list of completion timestamps.
    """

    def __init__(self, name: str, periodicity: str, created_at: Optional[datetime] = None):
        # Validate periodicity to avoid invalid habits
        if periodicity not in ("daily", "weekly"):
            raise ValueError("Periodicity must be 'daily' or 'weekly'.")

        self.name = name  # Name of the habit
        self.periodicity = periodicity  # daily or weekly
        self.created_at = created_at or datetime.now()  # When the habit was created
        self.completions: List[datetime] = []  # List of completion timestamps

    def complete_task(self) -> None:
        """Record a completion timestamp for the habit."""
        self.completions.append(datetime.now())

    def streak(self) -> int:
        """Calculate the current streak based on periodicity."""
        if not self.completions:
            return 0

        # Ensure completions are sorted chronologically
        self.completions.sort()

        streak = 1
        for prev, curr in zip(self.completions, self.completions[1:]):
            delta = (curr - prev).days

            if self.periodicity == "daily" and delta == 1:
                streak += 1
            elif self.periodicity == "weekly" and delta == 7:
                streak += 1
            else:
                streak = 1  # Reset streak if broken

        return streak

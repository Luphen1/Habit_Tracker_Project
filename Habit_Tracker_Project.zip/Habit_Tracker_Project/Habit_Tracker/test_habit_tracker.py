import unittest
from datetime import datetime
from habit import Habit

class TestHabitTracker(unittest.TestCase):
    """Unit tests for the Habit class."""

    def test_habit_creation(self):
        # Test that a habit is created with correct attributes
        h = Habit("Test Habit", "daily")
        self.assertEqual(h.name, "Test Habit")
        self.assertEqual(h.periodicity, "daily")

    def test_habit_completion(self):
        # Test that completing a habit adds a timestamp
        h = Habit("Test Habit", "daily")
        h.complete_task()
        self.assertEqual(len(h.completions), 1)

    def test_daily_streak(self):
        # Test streak calculation for daily habits
        h = Habit("Daily Habit", "daily")
        h.completions = [
            datetime(2024, 1, 1),
            datetime(2024, 1, 2),
            datetime(2024, 1, 3)
        ]
        self.assertEqual(h.streak(), 3)

    def test_weekly_streak(self):
        # Test streak calculation for weekly habits
        h = Habit("Weekly Habit", "weekly")
        h.completions = [
            datetime(2024, 1, 1),
            datetime(2024, 1, 8),
            datetime(2024, 1, 15)
        ]
        self.assertEqual(h.streak(), 3)

    def test_invalid_periodicity(self):
        # Test that invalid periodicity raises an error
        with self.assertRaises(ValueError):
            Habit("Bad Habit", "monthly")

if __name__ == "__main__":
    unittest.main()

